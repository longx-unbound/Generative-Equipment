#!/usr/bin/env python3
"""Exact finite checks for ENDO-5. No random sampling or external packages.

These checks validate concrete examples, not the general reconstruction theorems.
Run: python verify_endo5.py [output_directory]
"""
from __future__ import annotations
from itertools import product
from pathlib import Path
import json
import sys


def subsets(n: int):
    return [frozenset(i for i in range(n) if mask & (1 << i))
            for mask in range(1 << n)]


def maps(n: int, m: int):
    return product(range(m), repeat=n)


def pull(f: tuple[int, ...], q: frozenset[int]) -> frozenset[int]:
    return frozenset(i for i, v in enumerate(f) if v in q)


def exists(f: tuple[int, ...], p: frozenset[int]) -> frozenset[int]:
    return frozenset(f[i] for i in p)


def forall(f: tuple[int, ...], p: frozenset[int], m: int) -> frozenset[int]:
    return frozenset(j for j in range(m)
                     if all(i in p for i, v in enumerate(f) if v == j))


def test_quantifiers():
    adj = frob = bc = 0
    for n, m in product(range(4), repeat=2):
        for f in maps(n, m):
            for p, q in product(subsets(n), subsets(m)):
                assert (exists(f, p) <= q) == (p <= pull(f, q))
                assert (pull(f, q) <= p) == (q <= forall(f, p, m))
                adj += 2
                assert exists(f, p & pull(f, q)) == exists(f, p) & q
                frob += 1
    for n, m, k in product(range(3), repeat=3):
        for f in maps(n, m):
            for g in maps(k, m):
                pb = [(i, j) for i in range(n) for j in range(k) if f[i] == g[j]]
                gp = tuple(i for i, _ in pb)
                fp = tuple(j for _, j in pb)
                for p in subsets(n):
                    pp = pull(gp, p)
                    assert pull(g, exists(f, p)) == exists(fp, pp)
                    assert pull(g, forall(f, p, m)) == forall(fp, pp, k)
                    bc += 2
    return {"adjunction_checks": adj, "frobenius_checks": frob,
            "beck_chevalley_checks": bc}


def test_subspace_logic():
    subs = [s for s in subsets(4) if 0 in s and
            all((a ^ b) in s for a in s for b in s)]
    assert len(subs) == 5
    def join(a, b):
        return frozenset(x ^ y for x in a for y in b)
    failures = []
    for a, b, c in product(subs, repeat=3):
        if a & join(b, c) != join(a & b, a & c):
            failures.append((sorted(a), sorted(b), sorted(c)))
    line = frozenset({0, 1})
    zero = frozenset({0})
    candidates = [s for s in subs if s & line <= zero]
    greatest = [s for s in candidates if all(t <= s for t in candidates)]
    assert len(failures) == 6
    assert not greatest
    return {"subspaces": 5, "distributivity_triples_examined": 125,
            "distributivity_failures": failures,
            "implication_to_zero_has_no_greatest_candidate": True}


def curvature(x: dict[int, tuple[int, int]], nonabelian: bool):
    result: dict[int, int] = {}
    keys = sorted(x)
    for pos, s in enumerate(keys):
        for t in keys[pos + 1:]:
            if s & t:
                continue
            coefficient = (x[s][0] * x[t][1] + x[s][1] * x[t][0]) if nonabelian else 0
            if coefficient:
                result[s | t] = result.get(s | t, 0) + coefficient
    return {k: v for k, v in result.items() if v}


def test_tangent_is_not_controller():
    checked = 0
    for p, q in product(range(-2, 3), repeat=2):
        x = {1: (1, 0), 2: (0, 1), 3: (p, q)}
        assert curvature(x, False) == {}
        assert curvature(x, True) == {3: 1}
        checked += 1
    return {"top_coefficient_choices_checked": checked,
            "abelian_cube_curvature": 0, "nonabelian_full_support_curvature": 1}


def test_metric_predicates():
    n = 4
    edges = [(i, j) for i in range(n) for j in range(i + 1, n)]
    samples = reconstruction = lipschitz = 0
    for weights in product(range(1, 4), repeat=len(edges)):
        d = [[0] * n for _ in range(n)]
        for (i, j), w in zip(edges, weights):
            d[i][j] = d[j][i] = w
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j])
        for i, j in product(range(n), repeat=2):
            for z in range(n):
                assert abs(d[z][i] - d[z][j]) <= d[i][j]
                lipschitz += 1
            assert max(abs(d[z][i] - d[z][j]) for z in range(n)) == d[i][j]
            reconstruction += 1
        samples += 1
    return {"weighted_graph_inputs": samples,
            "distance_profile_lipschitz_checks": lipschitz,
            "distance_reconstruction_checks": reconstruction,
            "note": "Shortest-path metrics may repeat; input graphs are distinct, metrics need not be."}


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
    out.mkdir(parents=True, exist_ok=True)
    results = {
        "protocol": "deterministic exact arithmetic; finite concrete regression only",
        "quantifier_semantics": test_quantifiers(),
        "subspace_logic_negative_control": test_subspace_logic(),
        "same_tangent_different_deformation": test_tangent_is_not_controller(),
        "metric_predicate_recovery": test_metric_predicates(),
        "status": "PASS",
        "does_not_establish": ["general reconstruction theorems", "literature originality",
                               "automated logical importance", "general computability"]
    }
    (out / 'validation_results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
