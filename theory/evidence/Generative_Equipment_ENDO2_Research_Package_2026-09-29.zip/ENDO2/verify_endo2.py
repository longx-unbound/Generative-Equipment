#!/usr/bin/env python3
"""Exact, dependency-free regression tests for ENDO-2.

Tests finite windows only.  Infinite statements (regular coherence and the
periodic resolution) are proved in the companion manuscript, not by sampling.
Usage: python verify_endo2.py --out ./results
"""
from __future__ import annotations
import argparse
import csv
import json
from math import gcd
from pathlib import Path
from typing import Iterable


def hom_images(src: int, dst: int) -> list[int]:
    """Images of 1 for homomorphisms Z/src -> Z/dst."""
    if src <= 0 or dst <= 0:
        raise ValueError("Cyclic group orders must be positive")
    return [x for x in range(dst) if src * x % dst == 0]


def rank_mod(matrix: list[list[int]], p: int) -> int:
    """Row rank over a prime field (the test suite uses 2, 3 and 5)."""
    if p not in (2, 3, 5):
        raise ValueError("This verifier supports primes 2, 3, 5")
    if not matrix:
        return 0
    a = [[x % p for x in row] for row in matrix]
    cols = len(a[0])
    if any(len(row) != cols for row in a):
        raise ValueError("Ragged matrix")
    row = 0
    for col in range(cols):
        pivot = next((j for j in range(row, len(a)) if a[j][col]), None)
        if pivot is None:
            continue
        a[row], a[pivot] = a[pivot], a[row]
        inv = pow(a[row][col], -1, p)
        a[row] = [v * inv % p for v in a[row]]
        for j in range(len(a)):
            if j != row:
                c = a[j][col]
                a[j] = [(u - c*v) % p for u, v in zip(a[j], a[row])]
        row += 1
        if row == len(a):
            break
    return row


def multiply(a: list[list[int]], b: list[list[int]], p: int) -> list[list[int]]:
    if not a or not b or len(a[0]) != len(b):
        raise ValueError("Invalid matrix dimensions")
    return [[sum(a[i][k]*b[k][j] for k in range(len(b))) % p
             for j in range(len(b[0]))] for i in range(len(a))]


def exact_relation_tests() -> tuple[list[dict], int]:
    """Declared exact sequences Cm -> Cmn -> Cn and Yoneda defects."""
    rows: list[dict] = []
    descent_cases = 0
    for m in range(2, 7):
        for n in range(2, 7):
            for t in range(1, 13):
                hy = hom_images(t, m*n)
                hz = hom_images(t, n)
                hi = {(n*x) % (m*n) for x in hom_images(t, m)}
                assert hi <= set(hy)
                image_p = {x % n for x in hy}
                kernel_p = {x for x in hy if x % n == 0}
                assert kernel_p == hi
                raw_quotient = len(hy) // len(hi)
                assert raw_quotient == len(image_p)
                defect_order = len(hz) // len(image_p)
                rows.append(dict(m=m, n=n, probe=t,
                                 raw_quotient_order=raw_quotient,
                                 old_quotient_profile_order=len(hz),
                                 exact_relation_defect_order=defect_order))
                # For every h:Ct -> Cn, form the actual finite pullback.
                # Projection onto Ct is surjective and h lifts to Cmn on it.
                for image_of_one in hz:
                    pb = [(a, b) for a in range(m*n) for b in range(t)
                          if a % n == image_of_one*b % n]
                    assert {b for _, b in pb} == set(range(t))
                    assert all(a % n == image_of_one*b % n for a, b in pb)
                    assert len(pb) == m*t
                    descent_cases += 1
    example = next(r for r in rows if r['m']==2 and r['n']==2 and r['probe']==2)
    assert example['raw_quotient_order'] == 1
    assert example['old_quotient_profile_order'] == 2
    assert example['exact_relation_defect_order'] == 2
    return rows, descent_cases


def koszul_tests() -> tuple[list[dict], int]:
    """C(n) tensor C(m) with d1=(n,m), d2=(-m,n).

    Integral homology is proved in the manuscript.  This independently checks
    H_i of the reduced complex over Z/q by enumerating images and kernels.
    """
    rows: list[dict] = []
    integral_pairs = 0
    for n in range(1, 17):
        for m in range(1, 17):
            d = gcd(n, m)
            primitive_cycle = (-m//d, n//d)
            assert n*primitive_cycle[0] + m*primitive_cycle[1] == 0
            assert gcd(abs(primitive_cycle[0]), abs(primitive_cycle[1])) == 1
            assert tuple(d*x for x in primitive_cycle) == (-m, n)
            integral_pairs += 1
            for q in range(2, 14):
                im1 = {(n*a + m*b) % q for a in range(q) for b in range(q)}
                ker1 = {(a,b) for a in range(q) for b in range(q)
                        if (n*a+m*b) % q == 0}
                im2 = {((-m*c) % q, (n*c) % q) for c in range(q)}
                ker2 = {c for c in range(q) if m*c % q == 0 and n*c % q == 0}
                assert im2 <= ker1
                h0, h1, h2 = q//len(im1), len(ker1)//len(im2), len(ker2)
                g = gcd(d, q)
                assert (h0,h1,h2) == (g,g*g,g)
                rows.append(dict(n=n,m=m,q=q,H0_order=h0,H1_order=h1,H2_order=h2))
    return rows, integral_pairs


def dual_number_tests() -> tuple[list[dict], int]:
    """Checks interior pieces of the periodic epsilon-resolution.

    A truncated resolution's top homology is NOT counted as an invariant.
    The algebraic argument supplies continuation to every degree.
    """
    rows: list[dict] = []
    periodic_checks = 0
    for p in (2,3,5):
        e = [[0,0],[1,0]]
        assert multiply(e,e,p) == [[0,0],[0,0]]
        image_e = {(0,a) for a in range(p)}
        kernel_e = {(0,b) for b in range(p)}
        assert image_e == kernel_e
        erank = rank_mod(e,p)
        assert erank == 1
        for degree in range(1,13):
            assert 2-erank-erank == 0
            periodic_checks += 1
        for degree in range(13):
            # Tensoring the proved infinite free resolution with k makes
            # both incoming and outgoing maps zero.
            hd = 1-rank_mod([[0]],p)-rank_mod([[0]],p)
            assert hd == 1
            rows.append(dict(p=p,degree=degree,tensor_resolution_H_dimension=hd))
        # Cone(epsilon) is perfect; its H^(-1),H^0 both have dimension 1.
        assert 2-erank == 1
        # Product of two finite cones: field dimensions 2,4,2.
        d1 = [[0,0,0,0],[1,0,1,0]]
        d2 = [[0,0],[-1,0],[0,0],[1,0]]
        assert multiply(d1,d2,p) == [[0,0],[0,0]]
        r1,r2 = rank_mod(d1,p),rank_mod(d2,p)
        assert (2-r1,4-r1-r2,2-r2) == (1,2,1)
    return rows, periodic_checks


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("Cannot write empty test records")
    with path.open('w',newline='',encoding='utf-8') as f:
        w = csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'results')
    args = ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    rel,descent = exact_relation_tests()
    kos,pairs = koszul_tests()
    dual,periodic = dual_number_tests()
    write_csv(args.out/'exact_relation_probes.csv',rel)
    write_csv(args.out/'koszul_modular_checks.csv',kos)
    write_csv(args.out/'dual_number_resolution_checks.csv',dual)
    result = dict(status='PASS',
                  exact_relation_probe_cases=len(rel),
                  nonzero_exact_relation_defect_cases=sum(r['exact_relation_defect_order']>1 for r in rel),
                  pullback_local_lifting_checks=descent,
                  integral_scalar_pair_checks=pairs,
                  reduced_koszul_homology_checks=len(kos),
                  periodic_resolution_interior_checks=periodic,
                  tensor_resolution_degree_checks=len(dual),
                  finite_cone_tensor_checks=3,
                  limits=['Finite windows are regression tests, not universal proofs.',
                          'No numerical test establishes infinite projective dimension.',
                          'No general complexity speedup or originality claim is tested.'])
    (args.out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
