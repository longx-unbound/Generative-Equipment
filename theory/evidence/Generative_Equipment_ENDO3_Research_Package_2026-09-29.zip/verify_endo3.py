#!/usr/bin/env python3
from itertools import combinations

def powerset(xs):
    xs = tuple(xs)
    for r in range(len(xs)+1):
        for s in combinations(xs, r):
            yield frozenset(s)

def relaxation_frontier(clauses, feasible):
    fs = [s for s in powerset(clauses) if feasible(s)]
    return [s for s in fs if not any(s < t for t in fs)]

K = {"faithful", "exact", "strong_monoidal", "exact_tensor"}
frontier = relaxation_frontier(K, lambda s: len(s) <= 3)
assert len(frontier) == 4
assert all(len(s) == 3 for s in frontier)

TOKENS = frozenset("abcd")
def T(s):
    s = set(s)
    if "a" in s: s.add("b")
    if "b" in s: s.add("c")
    if "a" in s and "c" in s: s.add("d")
    return frozenset(s)

x = frozenset({"a"})
states = [x]
while True:
    y = T(x)
    if y == x:
        break
    assert x <= y
    x = y
    states.append(x)
assert x == TOKENS
print("relaxation_frontier_size =", len(frontier))
print("doctrine_chain =", ["".join(sorted(s)) for s in states])
print("least_fixed_point =", "".join(sorted(x)))
print("ENDO-3 finite sanity checks: PASS")
