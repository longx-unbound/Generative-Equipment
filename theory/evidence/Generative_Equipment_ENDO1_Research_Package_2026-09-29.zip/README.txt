ENDO-1 v0.1 (2026-09-29)

Main manuscript: Generative_Equipment_ENDO1_Intrinsic_Problem_Generation_2026-09-29.md
Run the bounded experiment with: python verify_endo1_integer_generator.py
Python standard library only. No network calls or nonstandard dependencies.
The output records are isomorphism-type computations, not chosen bases or full natural equivalences.
Finite checks do not replace the proofs in the manuscript.
Frozen v1.0 is unchanged. This is a new derived research branch, not an automatic Library overwrite.
