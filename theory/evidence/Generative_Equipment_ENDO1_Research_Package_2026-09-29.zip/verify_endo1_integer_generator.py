#!/usr/bin/env python3
"""Finite, target-free checks for ENDO-1's additive problem generator.

Input: all 2 x 2 integer matrices with coefficients in [-2,2].
No desired cokernel is supplied. Output: kernels/cokernels up to abelian-group
isomorphism. These bounded tests do NOT prove the categorical theorems.
Only Python's standard library is used.
"""
from collections import Counter
from itertools import product
from math import gcd
import json
from pathlib import Path


def signature(a):
    """(free rank, nontrivial torsion invariant factors) of coker(A)."""
    x, y, z, w = a
    d1 = gcd(gcd(abs(x), abs(y)), gcd(abs(z), abs(w)))
    det = x*w-y*z
    if d1 == 0:
        return (2, ())
    if det == 0:
        return (1, (d1,) if d1 > 1 else ())
    d2 = abs(det)//d1
    assert d2 % d1 == 0
    return (0, tuple(d for d in (d1, d2) if d > 1))


def transforms(a):
    x,y,z,w = a
    return [
        (z,w,x,y), (y,x,w,z), (-x,-y,z,w), (x,-y,z,-w),
        (x+z,y+w,z,w), (x,x+y,z,z+w),
    ]


def modular_kernel_count(a, modulus):
    x,y,z,w = a
    return sum((x*u+y*v) % modulus == 0 and
               (z*u+w*v) % modulus == 0
               for u,v in product(range(modulus), repeat=2))


def signature_modular_count(sig, modulus):
    rank, torsion = sig
    value = modulus**rank
    for d in torsion:
        value *= gcd(d, modulus)
    return value


def main():
    counts = Counter()
    requests = []
    new_requests = 0
    basis_checks = modular_checks = 0
    matrices = list(product(range(-2,3), repeat=4))
    for a in matrices:
        sig = signature(a)
        counts[sig] += 1
        for kind, out_sig in (("kernel", (sig[0], ())), ("cokernel", sig)):
            requests.append({
                "source_matrix_row_major": list(a),
                "input_objects": ["Z^2", "Z^2"],
                "question_type": kind,
                "question": "Is the generated observation profile realizable by a finite free abelian group?",
                "computed_isomorphism_type": {
                    "free_rank": out_sig[0],
                    "torsion_invariant_factors": list(out_sig[1]),
                },
                "realizable_in_initial_free_world": not bool(out_sig[1]),
                "output_scope": "isomorphism type; no chosen basis/realization map is returned",
            })
        new_requests += bool(sig[1])  # finite free groups have no torsion
        for b in transforms(a):
            assert signature(b) == sig, (a,b)
            basis_checks += 1
        for q in range(2,9):
            # Over a finite endomorphism X->X, |kernel| = |cokernel|.
            assert modular_kernel_count(a,q) == signature_modular_count(sig,q)
            modular_checks += 1
    cyclic_checks = 0
    for n in range(1,33):
        for m in range(-32,33):
            ker = sum((m*x) % n == 0 for x in range(n))
            image = {(m*x) % n for x in range(n)}
            assert ker == gcd(m,n) == n//len(image)
            cyclic_checks += 1
    result = {
        'scope': 'bounded 2x2 integer-arrow problem generation, not a proof of general theory',
        'input_matrices': len(matrices),
        'generated_kernel_and_cokernel_requests': 2*len(matrices),
        'cokernel_requests_not_realizable_as_finite_free_groups': new_requests,
        'cokernel_isomorphism_types': len(counts),
        'cokernel_types': [
            {'free_rank': k[0], 'torsion_invariant_factors': list(k[1]), 'multiplicity': v}
            for k,v in sorted(counts.items())
        ],
        'basis_change_checks': basis_checks,
        'independent_modular_count_checks': modular_checks,
        'second_round_cyclic_endomorphism_checks': cyclic_checks,
        'status': 'PASS',
    }
    request_path = Path(__file__).with_name('endo1_generated_requests.jsonl')
    request_path.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in requests)+"\n", encoding='utf-8')
    out = Path(__file__).with_name('endo1_verification_results.json')
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
