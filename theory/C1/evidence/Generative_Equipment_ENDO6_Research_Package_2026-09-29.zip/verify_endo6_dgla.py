from fractions import Fraction
from itertools import product

L1 = ['v1','v2','v3','v4','e12','e34']
L2 = ['p12','p34','w']

d = {
    'v1':{}, 'v2':{}, 'v3':{}, 'v4':{},
    'e12':{'p12':Fraction(1)},
    'e34':{'p34':Fraction(1)},
    'p12':{}, 'p34':{}, 'w':{}
}

basic = {
    tuple(sorted(('v1','v2'))): {'p12':Fraction(-1)},
    tuple(sorted(('v3','v4'))): {'p34':Fraction(-1)},
    tuple(sorted(('e12','e34'))): {'w':Fraction(1)},
}

def add(a,b,scale=Fraction(1)):
    out=dict(a)
    for k,v in b.items():
        out[k]=out.get(k,Fraction(0))+scale*v
        if out[k]==0:
            del out[k]
    return out

def bracket_basis(x,y):
    if x in L2 or y in L2:
        return {}
    return dict(basic.get(tuple(sorted((x,y))), {}))

def bracket(a,b):
    out={}
    for x,cx in a.items():
        for y,cy in b.items():
            out=add(out, bracket_basis(x,y), cx*cy)
    return out

def diff(a):
    out={}
    for x,c in a.items():
        out=add(out,d[x],c)
    return out

# d^2=0
for x in L1+L2:
    assert diff(diff({x:Fraction(1)})) == {}

# derivation on degree-one basis pairs: RHS vanishes because d(x),d(y) are central degree two
for x in L1:
    for y in L1:
        assert diff(bracket_basis(x,y)) == {}

# Jacobi: every bracket lands in central degree two
for x,y,z in product(L1, repeat=3):
    assert bracket({x:Fraction(1)}, bracket_basis(y,z)) == {}

# H^2 class w is nonexact
im_d_basis = {'p12','p34'}
assert 'w' not in im_d_basis

# Base proper-subfamily fillers satisfy pair equations.
# [v1,v2]=-p12 and d(e12)=p12; [v3,v4]=-p34 and d(e34)=p34.
assert add(diff({'e12':Fraction(1)}), bracket_basis('v1','v2')) == {}
assert add(diff({'e34':Fraction(1)}), bracket_basis('v3','v4')) == {}

print('ENDO-6 DGLA sanity checks: PASS')
print('dim L^1 =', len(L1))
print('dim L^2 =', len(L2))
print('total dimension =', len(L1)+len(L2))
print('H^2 obstruction representative w is not exact')
